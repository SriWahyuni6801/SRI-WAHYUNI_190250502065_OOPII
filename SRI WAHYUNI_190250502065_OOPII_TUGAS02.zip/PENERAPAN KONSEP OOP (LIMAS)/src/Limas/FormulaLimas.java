/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Limas;

/**
 *
 * @author NIKU
 */
public class FormulaLimas {
    private int luas;
    private int tinggi;
public void setLuas(int luas)
{
    this.luas = luas;
}
public void setTinggi (int tinggi)
{
    this.tinggi = tinggi;
}
public int getLuas()
{
    return luas;
}
public int getTinggi()
{
    return tinggi;
}
public double hitungVolume()
{
    double Volume;
    Volume=  luas * tinggi * 1/3;
    return Volume;
}
}

