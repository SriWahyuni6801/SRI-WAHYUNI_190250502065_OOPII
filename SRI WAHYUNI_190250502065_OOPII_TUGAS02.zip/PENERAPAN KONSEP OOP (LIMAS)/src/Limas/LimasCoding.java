/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Limas;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author NIKU
 */
public class LimasCoding {
    public static void main(String[] args) {
        BufferedReader dataIn = new BufferedReader (new InputStreamReader(System.in));
        FormulaLimas Limas = new FormulaLimas ();
        try
        {
            System.out.println("Masukkan Nilai Luas Limas : ");
            String a = dataIn.readLine();
            Limas.setLuas(Integer.parseInt(a));
            
            System.out.println("Masukkan Nilai Tinggi Limas : ");
            String b = dataIn.readLine();
            Limas.setTinggi(Integer.parseInt(b));
            
            System.out.println("Luas Limas Adalah : "+Limas.getLuas());
            System.out.println("Tinggi Limas Adalah : "+Limas.getTinggi());
            System.out.println("Volume Limas Adalah : "+Limas.hitungVolume());
        }
        catch (IOException e)
        {
    }
    }
    }
